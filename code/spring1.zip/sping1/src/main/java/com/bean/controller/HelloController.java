package com.bean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by BeanDu
 * Date: 2017-10-01 18:41
 * Project Name: sping1
 */

@Controller
@RequestMapping("/hello")
public class HelloController {

    @RequestMapping("/index")
    public void hello(HttpServletResponse resp) throws IOException {
        resp.getWriter().print("hello spring .");

    }
}