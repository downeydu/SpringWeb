package com.bean.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.concurrent.Callable;

/**
 * Created by BeanDu
 * Date: 2017-10-03 08:10
 * Project Name: spring5
 */

@Component("cal")
@Scope("prototype")
public class Calculator {



    public int sum(int a,int b) throws InterruptedException {
        int sum = 0;
        sum = a+b;
        Thread.sleep(500);
        return sum;
    }


    public double sub(double a,double b)  {
        double re = 0.0;
        if (b == 0.0) throw new IllegalArgumentException("被除数不能为0！");
        return a/b;


    }


}