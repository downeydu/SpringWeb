package com.bean.aspect;

import com.bean.controller.Calculator;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by BeanDu
 * Date: 2017-10-03 08:58
 * Project Name: spring5
 */

@Aspect
@Component("logaspect")

public class LoggingAspect {
    private static final Logger logger = LoggerFactory.getLogger(Calculator.class);

    //int 可以转为 double,反之不行
    @Before("execution(public * com.bean.controller.Calculator.*(..)) && args(a,b)")
    private void beforeLog2(JoinPoint jp, double a, double b) {
        logger.info("Before: " + jp.getSignature() + ",参数(" + a + "," + b + ")");
    }


    @AfterReturning(pointcut = "execution(public * com.bean.controller.Calculator.*(..))",returning = "re")
    public void afterturnMethod(Object re){
        logger.info("AfterReturning:"+ " result is "+re.toString());
    }


    @AfterThrowing(pointcut = "execution(public * com.bean.controller.Calculator.*(..))", throwing = "ex")
    private void throwLog(IllegalArgumentException ex) {

        logger.info("AfterThrowing 异常: " + ex.toString());
    }


    @Around("execution(public * com.bean.controller.Calculator.*(..)) && args(a,b)")
    private Object aroundTime(ProceedingJoinPoint jp, double a, double b) throws Throwable {
        //误差很大
        long start = System.currentTimeMillis();
        Object retVal = jp.proceed();
        long end = System.currentTimeMillis();

        logger.info("Around执行时间:" + (end - start) + "ms");

        return retVal;
    }


}