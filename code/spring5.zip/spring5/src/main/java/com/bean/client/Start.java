package com.bean.client;

import com.bean.controller.Calculator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by BeanDu
 * Date: 2017-10-03 09:32
 * Project Name: spring5
 */

public class Start {
    public static void main(String[] args) throws InterruptedException {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("application-context.xml");
        Calculator cal = context.getBean("cal",Calculator.class);

        System.out.println("sout:"+cal.sub(6,1));

    }

}