package com.bean.controller;

import javafx.beans.binding.IntegerBinding;
import org.springframework.context.annotation.Bean;

import java.util.Map;

/**
 * Created by BeanDu
 * Date: 2017-10-01 19:36
 * Project Name: spring2
 */


public class Driver {

//        private Header header;
//
//        public Driver(Header header) {
//            this.header = header;
//        }

    private String type;

    private int size;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    //    public Driver(Map<String,String> param){
//        this.type = param.get("type");
//        this.size = Integer.valueOf(param.get("size"));
//    }


//    public Driver(String type, int size) {
//        this.type = type;
//        this.size = size;
//    }

    public void use(){
        System.out.println("I am using a "+type+" Driver,size is "+size);
    }

    public void init(){
        System.out.println("initialize Driver class");
    }

    public void destory(){
        System.out.println("destory Driver Class");
    }



}