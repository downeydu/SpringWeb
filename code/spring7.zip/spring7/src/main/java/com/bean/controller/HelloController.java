package com.bean.controller;

//~--- non-JDK imports --------------------------------------------------------

import com.bean.schema.User;

import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

//~--- JDK imports ------------------------------------------------------------

import java.io.IOException;
import java.io.Writer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by BeanDu
 * Date: 2017-10-05 09:22
 * Project Name: spring7
 */
@Controller
@RequestMapping("/hello")
public class HelloController {
    @RequestMapping("/test/{name}")
    public void test(@PathVariable("name") String username, @RequestParam("msg") String msg,    // ���get post����
                     @RequestHeader("host") String host, HttpServletRequest req, Writer writer) throws IOException {
        if (username.equals("") || (username == null)) {
            username = "empty";
        }

        writer.write("\n username=" + username);
        writer.write("\n msg=" + msg);
        writer.write("\n host=" + host);
        writer.write("\n getAuthType():" + req.getAuthType());
        writer.write("\n getContextPath():" + req.getContextPath());
        writer.write("\n getRemoteUser():" + req.getRemoteUser());
        writer.write("\n req.getLocalAddr()=" + req.getLocalAddr() + "\n req.getLocalName()=" + req.getLocalName()
                     + "\n req.getLocalPort()=" + req.getLocalPort());
        writer.write("\n req.getProtocol():" + req.getProtocol());
        writer.write("\n req.getRemoteUser()=" + req.getRemoteUser() + "\n req.getRemoteAddr()=" + req.getRemoteAddr()
                     + "\n req.getRemoteHost()=" + req.getRemoteHost());
    }

    @RequestMapping("/login")
    public void login(@ModelAttribute User user, Writer wr) throws IOException {


        String username = user.getUsername();
        String passwd   = user.getPassword();

        if (username.equals("jack") && passwd.equals("111111")) {
            wr.write("login success!!!");
        } else {
            wr.write("login failed!!!");
        }
    }

    @RequestMapping(
        path   = "/file",
        method = RequestMethod.POST
    )
    public void forUpload(@RequestParam("upfile") MultipartFile file,Writer wr) throws IOException {
        wr.write("\n filename = "+file.getName());
        wr.write("\n filetype = "+file.getContentType());
        wr.write("\n filesize = "+file.getSize()/1024.0+"kb");
        wr.write("\n getOriginalFilename = "+file.getOriginalFilename());
        wr.write("\n toString = "+file.toString());
        wr.write("\n getInputStream = "+file.getInputStream());
        wr.write("\n isEmpty = "+file.isEmpty());

    }
}


//~ Formatted by Jindent --- http://www.jindent.com
