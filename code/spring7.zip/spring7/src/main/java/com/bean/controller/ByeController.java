package com.bean.controller;

//~--- non-JDK imports --------------------------------------------------------

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//~--- JDK imports ------------------------------------------------------------

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

/**
 * Created by BeanDu
 * Date: 2017-10-05 09:22
 * Project Name: spring7
 */
@Controller
@RequestMapping("/bye")
public class ByeController {
    @RequestMapping("/index")
    public void hello(HttpServletResponse resp) throws IOException {
        resp.getWriter().print("bye spring .");
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
