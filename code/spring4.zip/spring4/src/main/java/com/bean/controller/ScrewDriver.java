package com.bean.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * Created by BeanDu
 * Date: 2017-10-02 10:17
 * Project Name: spring4
 */

@Component("screwdriver")
public class ScrewDriver {

    @Autowired
    private Header header;

    public void use(){
        System.out.println("screwdriver:I am using "+header.getType()+",size is "+header.getSize());
    }

    @PostConstruct
    public void init(){
        System.out.println("init screwdriver");
    }

    @PreDestroy
    public void destory(){
        System.out.println("destory screwdriver");
    }


}