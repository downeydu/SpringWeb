package com.bean.controller;

import javafx.beans.binding.IntegerBinding;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by BeanDu
 * Date: 2017-10-01 19:36
 * Project Name: spring2
 */

@Component("Driver")
public class Driver {

    @Value("${type}")
    private String type;

    @Value("${size}")
    private int size;


    public void use(){
        System.out.println("driver:I am using a "+type+" Driver,size is "+size);
    }

    public void init(){
        System.out.println("initialize Driver class");
    }

    public void destory(){
        System.out.println("destory Driver Class");
    }



}