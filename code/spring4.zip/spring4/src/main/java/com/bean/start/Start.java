package com.bean.start;

import com.bean.controller.Driver;
import com.bean.controller.ScrewDriver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by BeanDu
 * Date: 2017-10-02 08:41
 * Project Name: spring3
 */

public class Start {
    public static void main(String[] args) {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("application-context.xml");
//        Driver driver = context.getBean("Driver",Driver.class);
        ScrewDriver driver = context.getBean("screwdriver",ScrewDriver.class);
        driver.use();
    }
}