package com.bean.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by BeanDu
 * Date: 2017-10-02 10:17
 * Project Name: spring4
 */

@Component("header")
public class Header {

    @Value("${type}")
    private String type;

    @Value("${size}")
    private int size;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}