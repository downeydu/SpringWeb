package com.bean.aspect;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by BeanDu
 * Date: 2017-10-03 08:58
 * Project Name: spring5
 */

@Aspect
@Component("logaspect")

public class LoggingAspect {
    private static final Logger logger = LoggerFactory.getLogger(LoggingAspect.class);

    //int 可以转为 double,反之不行
    @Before("execution(public * com.bean.dao.PersonDao.*(..))")
    private void beforeLog2(JoinPoint jp) {
        Object[] args = jp.getArgs();
        String arg = "";
        for(int i=0;i<args.length;i++){

            String str = null;
            try {
                str = (String)args[i];
            } catch (Exception e) {
                str = String.valueOf(args[i]);
            }
            arg = arg+"param"+i+"="+str+" ";

        }
        logger.info("Before: " + jp.getSignature() + ",参数(" + arg + ")");
    }


    @AfterReturning(pointcut = "execution(public * com.bean.dao.PersonDao.get*(..))",returning = "re")
    public void afterturnMethod(Object re){
        logger.info("AfterReturning:"+ " result is "+re.toString());
    }


}