package com.bean.dao;

import com.bean.schema.Person;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;


import java.util.Date;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-10-04 09:48
 * Project Name: spring6
 */

@Component("persondao")
public interface PersonDao {

    @Select("select * from person")
    public List<Person> getPersonList();

    @Select("select * from person where id = #{id}")
    public Person getPersonById(int id);

    @Update("update person set balance = #{param2} where id = #{param1}")
    public void updatePersonById(int id,double balance);

    @Insert("insert into person(name,passwd,regtime,balance) values(#{param1},md5(#{param2}),#{param3},#{param4})")
    public void insertPerson(String name, String passwd, Date regtime,int balance);

    @Delete("delete from person where id = #{id}")
    public void delPerson(int id);


}