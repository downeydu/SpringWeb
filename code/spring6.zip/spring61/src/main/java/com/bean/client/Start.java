package com.bean.client;

import com.bean.controller.PersonController;
import com.bean.schema.Person;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by BeanDu
 * Date: 2017-10-04 10:04
 * Project Name: spring6
 */

public class Start {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");

        PersonController pc = context.getBean("personcontroller", PersonController.class);
//        Person person = pc.getPerson(2);
//        System.out.println("id:"+person.getId()+"  name:"+person.getName());

//        pc.delete(8);
//        pc.update(7,100);
//        pc.insert("frank","38224803",100);

        pc.change(7,61,10);


//        System.out.println("id:"+person2.getId()+"  name:"+person2.getName());
    }
}






