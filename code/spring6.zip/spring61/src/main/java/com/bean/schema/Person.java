package com.bean.schema;

import java.util.Date;

/**
 * Created by BeanDu
 * Date: 2017-10-04 09:41
 * Project Name: spring6
 */

public class Person {
    private int id;

    private String passwd;

    private String name;

    private Date time;

    private int balance;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }
}