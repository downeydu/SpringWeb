package com.bean.controller;

import com.bean.dao.PersonDao;
import com.bean.schema.Person;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * Created by BeanDu
 * Date: 2017-10-03 08:10
 * Project Name: spring5
 */

@Component("personcontroller")
@Scope("prototype")
public class PersonController {

    @Autowired
    private PersonDao dao;

    public Person getPerson(int id){
        return dao.getPersonById(id);
    }

    public List<Person> getList(){
        return dao.getPersonList();
    }

    public void update(int id,int balance){
        dao.updatePersonById(id,balance);
    }

    public void delete(int id){
        dao.delPerson(id);
    }

    public void insert(String name, String passwd,  int balance){

        Date regtime = new Date();
        dao.insertPerson(name,passwd,regtime,balance);
    }

    @Transactional
    public void change(int id1 ,int id2 ,int balance){
        int b1 = dao.getPersonById(id1).getBalance();
        dao.updatePersonById(id1,b1-balance);

        int b2 = dao.getPersonById(id2).getBalance();
        dao.updatePersonById(id2,b2+balance);

        System.out.println("changge success!!!");

    }


}