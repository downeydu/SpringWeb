package com.bean.start;

import com.bean.controller.ScrewDriver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by BeanDu
 * Date: 2017-10-01 19:21
 * Project Name: spring2
 */

public class Start {
    public static void main(String[] args) {
        ApplicationContext context =
                new ClassPathXmlApplicationContext("application-context.xml");
        ScrewDriver driver = context.getBean("ScrewDriver",ScrewDriver.class);
        driver.use();
    }
}