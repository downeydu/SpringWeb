package com.bean.controller;

import org.springframework.context.annotation.Bean;

/**
 * Created by BeanDu
 * Date: 2017-10-01 19:36
 * Project Name: spring2
 */


public class ScrewDriver {

    public void init(){
        System.out.println("initialize ScrewDriver class");
    }

    public void use(){
        System.out.println("I am using a ScrewDriver");
    }

    public void destory(){
        System.out.println("destory ScrewDriver Class");
    }



}