package com.bean.controller;

import com.bean.schema.User;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-10-06 08:48
 * Project Name: spring8
 */

@Controller
@RequestMapping("/user")
public class UserController {

    @RequestMapping("/a")
    public ModelAndView usera(){
        ModelAndView model = new ModelAndView("usera");
//        可以放入对象或者属性
        User jack = new User();
        jack.setUsername("jack");
        jack.setPassword("230842384");

        User tom = new User();
        tom.setUsername("tom");
        tom.setPassword("200299393");

        List<User> users =new  ArrayList<>();
        users.add(jack);
        users.add(tom);

        model.addObject("users",users);

        return model;

    }


    @RequestMapping("/b/{username}")
    public String userb(@PathVariable String username, ModelMap model){
        String name = username;
        model.addAttribute("username",name);
        return "userb";

    }


}