package com.bean.client;

//~--- non-JDK imports --------------------------------------------------------

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by BeanDu
 * Date: 2017-10-04 10:04
 * Project Name: spring6
 */
public class Start {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("application-context.xml");
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
