package com.bean.filter;

import javax.servlet.*;
import java.io.IOException;

/**
 * Created by BeanDu
 * Date: 2017-10-05 11:32
 * Project Name: spring7
 */

public class FilterCharset implements Filter {
    private String charset;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

        this.charset = filterConfig.getInitParameter("charset");
        System.out.println("charset filter initialize,charset="+this.charset);
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {

        req.setCharacterEncoding(charset);
        resp.setCharacterEncoding(charset);
        chain.doFilter(req,resp);
    }

    @Override
    public void destroy() {
        System.out.println("charset filter destory");
    }
}